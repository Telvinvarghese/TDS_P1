#Unformatted Markdown

This is a sample paragraph with extra spaces and trailing whitespace.

- First item
- Second item
  +Third item


    *    Fourth item

```py
print("22f2001640@ds.study.iitm.ac.in")

```
